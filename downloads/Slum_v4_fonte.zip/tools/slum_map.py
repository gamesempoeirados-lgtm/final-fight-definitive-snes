"""Rebuild the Slum camera from CPS-1 gfx ROMs and a matching FBA RAM snapshot."""
from pathlib import Path
from zipfile import ZipFile
import argparse, csv, json
import numpy as np
from PIL import Image


def decode(archive):
    with ZipFile(archive) as rom:
        lanes = [np.frombuffer(rom.read(n), np.uint8).reshape(-1, 2)
                 for n in ('ff-5m.7a','ff-7m.9a','ff-1m.3a','ff-3m.5a')]
    groups = np.stack(lanes, axis=1).reshape(-1,4,1)
    return (np.unpackbits(groups,axis=2) * np.array([1,2,4,8])[None,:,None]).sum(axis=1).astype(np.uint8)


def rebuild(archive,snapshot,out):
    out.mkdir(exist_ok=True,parents=True)
    gfx=decode(archive)
    regs=np.fromfile(snapshot/'CpsReg',dtype='<u2').astype(int)
    ram=np.fromfile(snapshot/'CpsRam90',dtype='<u2')
    pal=np.fromfile(snapshot/'CpsSavePal',dtype='<u2').astype(int)
    rgb=np.stack([((pal>>n)&15)*17*(15+2*(pal>>12))//45 for n in (8,4,0)],axis=1)
    # Match the captured libretro RGB565 output, including Pillow expansion.
    rgb=((rgb>>[3,2,3])*255//[31,63,31]).astype(np.uint8)
    canvas=np.zeros((224,512,3),dtype=np.uint8)
    records=[]
    for layer,size in ((3,32),(2,16)):
        bank=(int(regs[layer])<<8)&0xffc000
        x0=(regs[4+layer*2]+64)%(64*size)
        y0=(regs[5+layer*2]+16)%(64*size)
        tiles=gfx.reshape(-1,size,size)
        layer_rgb=np.zeros_like(canvas)
        for y in range(-(y0%size),224,size):
            for x in range(-(x0%size),512,size):
                tx=((x+x0)//size)&63
                ty=((y+y0)//size)&63
                offset=((ty&48)<<8)|(tx<<6)|((ty&15)<<2) if layer==2 else ((ty&56)<<8)|(tx<<5)|((ty&7)<<2)
                address=bank+offset
                code,attr=map(int,ram[(address-0x900000)//2:][:2])
                records.append((layer,x,y,hex(address),hex(code),hex(attr),attr&31))
                if not ((0x3000<=code<0x4000) if layer==2 else (0x980<=code<0xc00)):continue
                pens=tiles[code]
                if attr&32:pens=pens[:,::-1]
                if attr&64:pens=pens[::-1]
                left,top=max(0,x),max(0,y)
                right,bottom=min(512,x+size),min(224,y+size)
                pens=pens[top-y:bottom-y,left-x:right-x]
                colors=rgb[(layer*32+(attr&31))*16+pens.astype(int)]
                mask=pens!=15
                for dest in (canvas,layer_rgb):
                    dest[top:bottom,left:right][mask]=colors[mask]
        Image.fromarray(layer_rgb).save(out/f'scroll{layer}.png')
    Image.fromarray(canvas).save(out/'slum.png')
    with (out/'cells.csv').open('w',newline='') as file:
        writer=csv.writer(file);writer.writerow(('layer','x','y','ram','code','attr','palette'));writer.writerows(records)
    return records


if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ('archive','snapshot','output'):p.add_argument(name,type=Path)
    args=p.parse_args(); rebuild(args.archive,args.snapshot,args.output)
