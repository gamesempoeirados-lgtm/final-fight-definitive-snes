"""Convert the verified panorama and chroma-keyed CPS1 poses to SNES tiles."""
from pathlib import Path
import sys,struct
import numpy as np
from PIL import Image
from scipy.cluster.vq import kmeans2

def encode(tile):
    return bytes(sum(((int(p)>>b)&1)<<(7-x) for x,p in enumerate(row))
                 for pair in (0,2) for row in tile for b in (pair,pair+1))

def palette(colors):
    return b''.join(struct.pack('<H',int(r>>3)|int(g>>3)<<5|int(b>>3)<<10) for r,g,b in colors)

def quant(samples):
    im=Image.fromarray(samples.reshape(-1,1,3))
    result=im.quantize(15,dither=Image.Dither.NONE)
    return np.array((result.getpalette()+[0]*45)[:45],dtype=np.uint8).reshape(15,3)

def indices(pixels,colors):
    delta=pixels[...,None,:].astype('int32')-colors
    return (1+(delta*delta).sum(-1).argmin(-1)).astype('uint8')

def pack(panorama,frames,out):
    pixels=np.array(Image.open(panorama)).reshape(28,8,64,8,3).transpose(0,2,1,3,4).reshape(-1,8,8,3)
    features=np.concatenate((pixels.mean((1,2)),pixels.std((1,2))),axis=1)
    _,groups=kmeans2(features,7,iter=25,minit='++',seed=41)
    pals=[quant(pixels[groups==i]) for i in range(7)]
    maps=np.zeros((32,64),dtype='<u2');unique={}
    for n,t in enumerate(pixels):
        g=groups[n];data=encode(indices(t,pals[g]))
        idx=unique.setdefault(data,len(unique));maps[n//64,n%64]=idx|((int(g)+1)<<10)
    assert len(unique)<=1024
    (out/'bg.chr').write_bytes(b''.join(unique))
    (out/'bg.map').write_bytes(maps[:,:32].tobytes()+maps[:,32:].tobytes())
    (out/'bg.pal').write_bytes(b''.join(bytes(2)+palette(p) for p in pals))
    def crop(n,box):
        a=np.array(Image.open(frames/f'{n}.png').crop(box))
        mask=(a!=[255,0,255]).any(-1);y,x=np.where(mask)
        sl=np.s_[y.min():y.max()+1,x.min():x.max()+1]
        return Image.fromarray(np.dstack((a[sl],mask[sl]*255)).astype('uint8'))
    poses=[crop(n,box) for n,box in [(900,(0,90,100,210)),(1159,(65,95,148,210)),(1177,(110,90,220,210)),(1254,(180,95,265,210)),(1254,(300,76,365,192)),(900,(112,150,171,224))]]
    # Use native pose proportions with a common scale for the actor group.
    pals2=[]
    for group in (poses[:4],poses[4:5],poses[5:]):
        samples=np.concatenate([np.array(im)[:,:,:3][np.array(im)[:,:,3]>0] for im in group])
        pals2.append(quant(samples))
    pages=[np.zeros((128,128),np.uint8) for _ in range(2)]
    for i,im in enumerate(poses):
        im=im.resize((round(im.width*.67),round(im.height*.67)),Image.Resampling.NEAREST)
        im.thumbnail((64,64),Image.Resampling.NEAREST);a=np.array(im);g=0 if i<4 else i-3
        tile=np.where(a[:,:,3]>0,indices(a[:,:,:3],pals2[g]),0)
        xx=(i%2)*64+(64-im.width)//2;yy=(i%4//2)*64+64-im.height
        pages[i//4][yy:yy+im.height,xx:xx+im.width]=tile
    # The extended fist occupies the unused bottom-right cell in OBJ page 1.
    extended=crop(1256,(175,95,288,205)).resize((54,60),Image.Resampling.NEAREST)
    a=np.array(extended)
    pages[1][68:128,74:128]=np.where(a[:,:,3]>0,indices(a[:,:,:3],pals2[0]),0)
    # Recoil isolated after Guy and his opponent separate in the contact trace.
    hurt=crop(1573,(257,80,325,210))
    hurt=hurt.resize((round(hurt.width*.67),round(hurt.height*.67)),Image.Resampling.NEAREST)
    hurt.thumbnail((64,64),Image.Resampling.NEAREST)
    a=np.array(hurt)
    x=(64-hurt.width)//2
    pages[1][128-hurt.height:,x:x+hurt.width]=np.where(a[:,:,3]>0,indices(a[:,:,:3],pals2[1]),0)
    pals2.append(np.minimum(pals2[1].astype(int)+70,255).astype('uint8'))
    for i,page in enumerate(pages):
        (out/f'obj{i}.chr').write_bytes(b''.join(encode(page[y:y+8,x:x+8]) for y in range(0,128,8) for x in range(0,128,8)))
    (out/'obj.pal').write_bytes(b''.join(bytes(2)+palette(p) for p in pals2))
    print(len(unique),'BG tiles')

if __name__=='__main__':pack(*map(Path,sys.argv[1:]))
