"""One original decaying percussion sample and a single-voice SPC700 player."""
import math
import struct


def payload():
    driver = bytearray()
    def mov(address, value):
        driver.extend((0x8f, value, address))  # MOV dp,#imm
    def dsp(register, value):
        mov(0xf2, register)
        mov(0xf3, value)
    for reg, val in ((0x6c,0x20),(0x0c,100),(0x1c,100),(0x5d,3),
                     (0x00,110),(0x01,110),(0x02,0),(0x03,0x10),
                     (0x04,0),(0x05,0),(0x07,0x7f),(0x5c,0)):
        dsp(reg,val)
    driver.extend((0xe4,0xf5,0xc4,0x10))  # last command = port 1
    loop = len(driver)
    driver.extend((0xe4,0xf5,0x64,0x10,0xf0,0xfa,0xc4,0x10))
    dsp(0x4c,1)
    driver.extend((0x2f,(loop-len(driver)-2) & 255))
    driver.extend(bytes(256-len(driver)))
    driver.extend(struct.pack('<HH',0x304,0x304))
    blocks = 96
    for block in range(blocks):
        nibbles = []
        for i in range(16):
            t = (16*block + i)/32000
            nibbles.append(round(7*math.exp(-64*t)*math.sin(2*math.pi*220*t)) & 15)
        driver.append(0xb0 | (block==blocks-1))  # range 11, filter 0, END on last
        driver.extend((a<<4)|b for a,b in zip(nibbles[::2], nibbles[1::2]))
    return driver


def install(s):
    data = payload()
    s.mark('ipl_ready')
    s.emit(0xad,0x40,0x21,0xc9,0xaa)
    s.br(0xd0,'ipl_ready')
    s.stz(0x2142)
    s.imm(2)
    s.sta(0x2143)
    s.imm(1)
    s.sta(0x2141)
    s.imm(0xcc)
    s.sta(0x2140)
    s.mark('ipl_accept')
    s.emit(0xcd,0x40,0x21)
    s.br(0xd0,'ipl_accept')
    s.emit(0xa2,0,0)
    s.mark('ipl_byte')
    s.emit(0xbd,0,0)
    s.fix.append(('abs',len(s.b)-2,'sound_data'))
    s.sta(0x2141)
    s.emit(0x8a)
    s.sta(0x2140)
    s.mark('ipl_echo')
    s.emit(0xcd,0x40,0x21)
    s.br(0xd0,'ipl_echo')
    s.emit(0xe8,0xe0,len(data)&255,len(data)>>8)
    s.br(0xd0,'ipl_byte')
    s.stz(0x2141)
    s.imm((len(data)+1)&255)
    s.sta(0x2140)
    s.stz(0x83)
    s.br(0x80,'sound_done')
    s.mark('sound_data')
    s.emit(*data)
    s.mark('sound_done')
