"""Count elapsed frames from a rising attack edge on either mapped controller."""
PHASE=(0xa6,0xa7)
HELD=(0xa8,0xa9)
EXTEND=7
RETRACT=13
END=17

def update(s,i):
    phase,held=PHASE[i],HELD[i]
    s.dp(0xa5,0x18);s.emit(0x29,64);s.br(0xd0,f'jab_pressed{i}')
    s.stz(held);s.br(0x80,f'jab_tick{i}')
    s.mark(f'jab_pressed{i}');s.dp(0xa5,held);s.br(0xd0,f'jab_tick{i}')
    s.imm(1);s.dp(0x85,held)
    s.dp(0xa5,phase);s.br(0xd0,f'jab_tick{i}');s.imm(1);s.dp(0x85,phase);s.br(0x80,f'jab_done{i}')
    s.mark(f'jab_tick{i}');s.dp(0xa5,phase);s.br(0xf0,f'jab_done{i}')
    s.dp(0xe6,phase);s.dp(0xa5,phase);s.emit(0xc9,END);s.br(0x90,f'jab_done{i}');s.stz(phase)
    s.mark(f'jab_done{i}')
