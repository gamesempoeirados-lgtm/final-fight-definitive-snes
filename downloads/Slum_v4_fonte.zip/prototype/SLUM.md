# Entrada de Slum
Base 3b60178. Execute build.py e depois test_runtime.py passando o núcleo Snes9x2005. O arquivo gerado se chama coop_street.sfc. A imagem tem 128 KiB e cabeçalho FastROM LoROM.

No quadro 900 do arcade, a tabela Scroll2 começa em $90C000, a Scroll3 em $910000 e a área de paleta em $914000. A ferramenta tools/slum_map.py combina os gráficos da ROM com as tabelas capturadas durante o jogo. As duas camadas e a composição tiveram zero diferenças na janela de 384 x 224 pixels, comparadas às três capturas independentes do mesmo estado. Isso valida as tabelas em RAM. A origem de todos os seus campos na ROM de programa continua em estudo.

Para o SNES, o panorama de 512 x 224 usa 727 tiles de 8 x 8 e sete paletas. As duas camadas rolam juntas. Os dois jogadores usam Guy; os três encontros usam o mesmo sprite de inimigo. O barril representa a barreira de teste. As colisões, o ritmo das poses e os gatilhos são do protótipo. A trilha da fase, a introdução e a validação física continuam pendentes.

Snes9x2005 confirmou os três encontros, controles cooperativos, bloqueio e avanço de câmera, menu, créditos, fogo amigo, salto e som de impacto.

## Slum v3

O inimigo usa a pose de reação do quadro 1573 da captura CPS-1 com ataque no quadro 1548. O tempo de atordoamento de 12 quadros é do protótipo. A última linha opaca nas poses de guarda e reação está em y=63 do objeto SNES de 64×64. O soco estendido também termina nessa linha. Falta validar o pivô horizontal e a reação no sentido inverso contra o CPS-1.

Snes9x2005 a79dfe9 executou os três encontros em 1P e 2P até a célula 32 da câmera. Com o alvo posicionado em RAM, houve um dano seis quadros após a entrada. O ataque errou atrás de Guy, além do alcance e em outra faixa de profundidade. O salto atingiu 24 pixels. O teste verifica os padrões e alterações do menu.

Contadores no núcleo registraram escritas da CPU em $2104 e $2118–19 e bytes de S9xDoDMA. Nos 806 quadros com atualização dos seis objetos (26 bytes OAM), o pico foi de 26 bytes de VRAM e nenhum DMA. A carga inicial usa DMA e fica fora dessa amostra. O planejador de cache simulado em 33 janelas sucessivas de 32×28 tiles necessitou de até 518 slots, 16.256 bytes na primeira janela e até 480 bytes por deslocamento de oito pixels. A ROM carrega os 727 tiles de cenário antes da partida.

Para reproduzir o binário, execute python prototype/build.py na raiz deste pacote. Execute python prototype/test_runtime.py CAMINHO_DO_NUCLEO_SNES9X2005 para os testes. O SHA-256 esperado da ROM é 53cec57a6bb5bc7375b3ee50a826d99f4758bdcbc5b8c2554ac6416b810b34f1.

## Prioridades após o teste da v3 no Android

O jogador relatou que Guy entra no cenário e que a caminhada parece rápida e antinatural. O ponto exato da invasão ainda precisa ser reproduzido.

- Percorrer a borda da rua e contornar os obstáculos nos dois sentidos, com a câmera parada e em rolagem. Conferir a posição dos pés em relação ao piso e a ordem de desenho quando Guy passa à frente ou atrás de um objeto. Repetir em 1P e 2P.
- Capturar no CPS-1 caminhadas horizontais, em profundidade e diagonais. Medir deslocamento relativo ao cenário por quadro, duração das poses e distância percorrida por passada. Usar as medidas para ajustar velocidade e cadência no SNES e repetir a comparação.
- O jogador observou o mesmo problema nos inimigos. Na v3, a perseguição altera X e Y e o recuo após um soco altera X sem consultar a colisão do barril usada por Guy. Testar a entrada de cada inimigo, a perseguição ao redor do barril e o recuo contra ele pelos dois lados. Conferir os pés na borda da rua e a ordem de desenho com a câmera parada e em movimento, em 1P e 2P.

## Slum v4

A v3 publicada reproduziu a invasão do barril pelo primeiro inimigo durante a perseguição e permitiu a Guy apoiar os pés em y=144. Na v4 a faixa adotada para a entrada é y=184–216. A largura e a profundidade das colisões são aproximações do cenário SNES. O barril foi colocado na pista com a base em y=199. Os seis objetos são ordenados pela profundidade dos pés. A câmera interpola o deslocamento e os objetos usam o mesmo deslocamento visual do cenário.

O ensaio CPS-1 partiu do mesmo estado inicial em três execuções, com direcional mantido do quadro 1150 em diante. Os registros da RAM de trabalho $FF856E e $FF8572 indicaram 2,09765625 pixels horizontais e 1 pixel em profundidade por quadro de caminhada. Na diagonal observada, os dois componentes se somaram. A sequência em $FF858E repetiu após 38 quadros na horizontal/diagonal e 40 na vertical. A planilha slum_walk_cps1.csv contém cada leitura. No port, o acumulador usa 1,40625 e 0,66796875 pixels por quadro seguindo a escala de 0,67 dos personagens. O ciclo usa duas poses convertidas das doze observadas no arcade.

A ROM v4 tem SHA-256 9666487156966da3bc442e3d0c76a0ef78ee3911646d4e224c5e509f0a345abe. O teste do emulador cobre a distância em 32 quadros, o obstáculo pelos dois lados, deslocamento da câmera, ordenação dos objetos e conclusão de três encontros em 1P e 2P.
