"""Drive the built ROM with two libretro pads, inspecting emulated work RAM."""
import ctypes as C
import hashlib
from pathlib import Path
import sys

core = C.CDLL(sys.argv[1])
pads = [set(), set()]
frames = []
callbacks = []


def connect(name, result, args, function):
    callback = C.CFUNCTYPE(result, *args)(function)
    callbacks.append(callback)
    getattr(core, 'retro_set_' + name)(callback)


def video(data, width, height, pitch):
    if data:
        pixels = C.string_at(data, pitch * height)
        frames.append(hashlib.sha256(pixels).digest())


u = C.c_uint
v = C.c_void_p
connect('environment', C.c_bool, [u, v], lambda cmd, arg: cmd == 10)
connect('video_refresh', None, [v, u, u, C.c_size_t], video)
connect('audio_sample', None, [C.c_int16, C.c_int16], lambda *_: None)
audio_peaks = []
def audio_samples(data, count):
    samples = C.cast(data, C.POINTER(C.c_int16))
    audio_peaks.append(max(map(abs, samples[:count*2]), default=0))
    return count
connect('audio_sample_batch', C.c_size_t, [v, C.c_size_t], audio_samples)
connect('input_poll', None, [], lambda: None)
connect('input_state', C.c_int16, [u,u,u,u], lambda port, device, index, button: port < 2 and button in pads[port])
core.retro_init()


class Game(C.Structure):
    _fields_ = [('path', C.c_char_p), ('data', v), ('size', C.c_size_t), ('meta', C.c_char_p)]


rom = (Path(__file__).parent/'coop_street.sfc').read_bytes()
buf = C.create_string_buffer(rom)
game = Game(b'coop_street.sfc', C.cast(buf,v), len(rom), None)
core.retro_load_game.restype = C.c_bool
assert core.retro_load_game(C.byref(game))
core.retro_get_memory_data.restype = C.POINTER(C.c_uint8)
ram = core.retro_get_memory_data(2)


def run(n, p1=(), p2=()):
    pads[:] = [set(p1), set(p2)]
    for _ in range(n):
        core.retro_run()


run(30)
assert list(ram[0x84:0x89]) == [1,1,4,0,0]
run(3,(3,))
run(5)
assert (ram[0x20], ram[0x22], ram[0x80]) == (8,16,0)
run(1, (), (7,))
run(2)
assert ram[0x22]*8+ram[0xb4] == 129 and ram[0x20] == 8, list(ram[0x20:0x24])
run(130,(7,), (7,))
assert (ram[0x80],ram[0x81],ram[0x30]) == (6,1,3), list(ram[0x80:0x83])
# Walk both players up against the lane boundary.
run(60,(4,), (4,))
assert ram[0x21] == ram[0x23] == 21
assert ram[0x80] == 6
# Approach each opponent using normal directional and attack inputs.
def clear_encounters(solo=False):
    for wave, base in enumerate((0x30, 0x50, 0x60), 1):
        for _ in range(500):
            if ram[0x81] == wave and ram[base] == 0:
                break
            x, y = ram[base+1], ram[base+9]
            buttons = []
            for px, facing in ((0x20,0x34),(0x22,0x3d)):
                dx, dy = x-ram[px], y-ram[px+1]
                pad = set()
                if dy:
                    pad.add(5 if dy > 0 else 4)
                if abs(dx) > 2 or (dx and bool(ram[facing]) != (dx>0)):
                    pad.add(7 if dx>0 else 6)
                if dx == 0:
                    pad.add(6 if ram[px]>0 else 7)
                if ram[0x79] % 2:
                    pad.add(1)
                buttons.append(pad)
            run(1, buttons[0], () if solo else buttons[1])
        assert ram[base] == 0 and ram[0x81] == wave, (wave,list(ram[base:base+12]))
        for _ in range(200):
            if ram[0x81] > wave or ram[0x80] == 32:
                break
            run(1, (7,), () if solo else (7,))
    assert (ram[0x80], ram[0x81]) == (32, 3)
clear_encounters()
run(150, (7,5), (7,5))
assert ram[0x20] == ram[0x22] == 28
assert ram[0x21] == ram[0x23] == 25
assert (ram[0x80], ram[0x81]) == (32, 3)
assert len(set(frames)) > 10
assert max(audio_peaks) > 150, max(audio_peaks)
print('Peak audio sample:', max(audio_peaks))
print(f'{len(frames)} video frames, {len(set(frames))} distinct; three encounters cleared, both pads and bounds verified')
def boot_menu():
    core.retro_reset()
    run(30)

def press(button):
    run(3,(button,))
    run(3)

# Solo, hard, six credits, B attack, friendly fire enabled.
boot_menu()
for button in (6,5,7,5,7,5,7,5,7,3):
    press(button)
assert list(ram[0x84:0x89]) == [0,2,6,1,1]
assert ram[0x3e] == 0
run(16,(4,))
run(70,(7,), (7,))
assert ram[0x20] == 10 and ram[0x22] == 16
run(70,(5,))
run(150,(7,))
assert (ram[0x81],ram[0x30]) == (1,4)
# Party defeat/credit recovery is tested with an injected death, after normal boot.
ram[0x35] = 0
run(3)
assert (ram[0x35],ram[0x3e],ram[0x86]) == (5,0,5)
# Compare friendly-fire on/off; drive P1 near P2 before attacking.
for enabled in (False,True):
    boot_menu()
    if enabled:
        for button in (5,5,5,5,7):
            press(button)
    press(3)
    run(35,(7,))
    run(3,(1,))
    assert ram[0x3e] == (4 if enabled else 5), (enabled,ram[0x3e])
print('Menu edits, solo mode, difficulty, barrier, credit and friendly-fire on/off verified')
boot_menu()
press(3)
for player in (0,1):
    heights=[]
    for _ in range(36):
        run(1,(0,) if player==0 else (), (0,) if player==1 else ())
        heights.append(ram[0xa0+player])
        assert ram[0xa0+(1-player)] == 0
    assert max(heights)==24 and heights[-8:]==[0]*8
    run(3)
    run(4,(0,) if player==0 else (), (0,) if player==1 else ())
    assert ram[0xa0+player]>0
    run(30)
    assert ram[0xa0+player]==0
print('Independent jumps, release, landing and held-button lockout passed')
for player in (0,1):
    boot_menu()
    press(3)
    ram[0x30]=3
    ram[0x31]=ram[0x20+player*2]+2
    ram[0x39]=ram[0x21+player*2]
    ram[0x3b]=50
    hp=[]
    for frame in range(35):
        buttons=(1,) if player or frame==0 else ()
        run(1,buttons if player==0 else (),buttons if player==1 else ())
        hp.append(ram[0x30])
    assert hp[:6]==[3]*6 and hp[6:]==[2]*29, (player,hp)
print('P1 tap and P2 hold: first damage at offset 6, one hit each')
boot_menu()
press(6)
press(3)
assert ram[0x3e]==0
run(150,(7,))
assert ram[0x81]==1
clear_encounters(solo=True)
print('Solo: three encounters cleared; camera reached final cell 32')
for dx,dy in ((6,0),(-2,0),(2,3)):
    boot_menu()
    press(3)
    ram[0x30]=3
    ram[0x31]=ram[0x20]+dx
    ram[0x39]=ram[0x21]+dy
    ram[0x3b]=50
    run(1,(1,))
    run(18)
    assert ram[0x30]==3,(dx,dy)
print('Misses verified beyond reach, behind Guy and outside his lane')
# At two camera offsets, place the opponent one cell from the barrel and
# drive actual pursuit / punch routines. Enemy coordinates are screen-relative.
for camera in (0,6):
    for direction in (1,-1):
        for strike in (False,True):
            boot_menu()
            press(3)
            ram[0x80]=camera
            edge=(10 if direction==1 else 17)-camera
            ram[0x30]=3
            ram[0x31]=edge
            ram[0x39]=22
            ram[0x21]=22
            ram[0x3e]=0
            ram[0x20]=edge+(-2 if strike else 3)*direction
            ram[0x34]=int(direction==1)
            if strike:
                ram[0x37]=0
                run(1,(1,))
                run(6)
                assert ram[0x30]==2
            else:
                ram[0x37]=15
                run(1)
            assert ram[0x31]==edge,(camera,direction,strike)
# Compare OAM order when the barrel overlaps a fighter's upper body.
boot_menu()
press(3)
for camera in (0,6,12):
    ram[0x80]=camera
    ram[0x30]=3
    ram[0x31]=28
    for y,front in ((21,False),(24,True)):
        ram[0x21]=y
        run(2)
        assert (ram[0xc8]<ram[0xcd])==front
        assert sorted(ram[0xc8:0xce])==list(range(6))
# Scroll while the lead player walks and verify world-space barrier and depth.
boot_menu()
press(3)
ram[0x22]=22
ram[0x20]=10
ram[0x21]=22
run(1,(7,),(7,))
assert ram[0x80]==1
for _ in range(30):
    run(1,(7,),(7,))
    assert ram[0x20]+ram[0x80]<=10
print('Enemy pursuit and knockback blocked from both sides at two camera positions; depth order and scrolling passed')
for pad,expected in (((7,),(45,0)),((5,),(0,21)),((7,5),(45,21))):
    boot_menu()
    press(3)
    ram[0x20]=4
    ram[0x21]=21
    run(32,pad)
    result=(ram[0x20]*8+ram[0xb2]-32,ram[0x21]*8+ram[0xb3]-168)
    assert result==expected,(pad,result)
    print('SNES distance in 32 frames',pad,result)
core.retro_unload_game()
core.retro_deinit()
