"""Setup screen. All glyphs are original 5x5 bitmaps."""
from street import rom_stream

PLAYERS, DIFFICULTY, CREDITS, SWAP, FRIENDLY, CURSOR, HELD = range(0x84,0x8b)
FONT = dict(zip(
 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-',
 ('0e111f1111','1e111e111e','0f1010100f','1e1111111e','1f101e101f',
  '1f101e1010','0f1013110f','11111f1111','0e0404040e','070202120c',
  '11121c1211','101010101f','111b151111','1119151311','0e1111110e',
  '1e111e1010','0e1111150f','1e111e1211','0f100e011e','1f04040404',
  '111111110e','1111110a04','1111151b11','110a040a11','110a040404',
  '1f0204081f','0e1315110e','040c04040e','0e1102041f','1e0106011e',
  '12121f0202','1f101e011e','0e101e110e','1f02040808','0e110e110e',
  '0e110f010e','00001f0000')))
START_TILE = 32
GLYPHS = {letter: START_TILE+i for i,letter in enumerate(FONT)}
ROWS = ((PLAYERS, ('1','2')), (DIFFICULTY, ('EASY','NORMAL','HARD')),
        (CREDITS, tuple(str(i) for i in range(1,10))),
        (SWAP, ('Y-B','B-Y')), (FRIENDLY, ('OFF','ON')))


def pos(s,x,y):
    addr = 32*y+x
    s.imm(addr&255); s.sta(0x2116)
    s.imm(addr>>8); s.sta(0x2117)


def write(s, text):
    for char in text:
        s.imm(GLYPHS.get(char,0)); s.sta(0x2118); s.stz(0x2119)


def setup(s):
    for field, value in ((PLAYERS,1),(DIFFICULTY,1),(CREDITS,4),(SWAP,0),(FRIENDLY,0),(CURSOR,0),(HELD,0)):
        s.imm(value); s.dp(0x85,field)
    s.imm(0); s.sta(0x2116)
    s.imm(0x12); s.sta(0x2117)
    chars = bytearray()
    for glyph in FONT.values():
        rows = [0]+[b<<2 for b in bytes.fromhex(glyph)]+[0,0]
        chars.extend(byte for row in rows for byte in (0,0))
        chars.extend(byte for row in rows for byte in (row,0))  # palette index 4
    rom_stream(s,'font', chars,(0x2118,0x2119))
    for row, text in ((4,'COOP STREET'),(7,'PLAYERS'),(9,'LEVEL'),(11,'CREDITS'),
                      (13,'ATTACK-JUMP'),(15,'TEAM DAMAGE'),(20,'UP-DOWN SELECT'),
                      (22,'LEFT-RIGHT CHANGE'),(24,'START PLAY')):
        pos(s,5,row); write(s,text)
    s.imm(1); s.sta(0x212c); s.sta(0x4200)
    s.mark('menu_refresh')
    s.imm(0x80); s.sta(0x2100)
    for i, (field,values) in enumerate(ROWS):
        pos(s,3,7+2*i)
        s.dp(0xa5,CURSOR); s.emit(0xc9,i)
        s.br(0xd0,f'no_cursor_{i}')
        s.imm(3); s.br(0x80,f'cursor_ready_{i}')
        s.mark(f'no_cursor_{i}'); s.imm(0)
        s.mark(f'cursor_ready_{i}'); s.sta(0x2118); s.stz(0x2119)
        pos(s,19,7+2*i)
        for j,value in enumerate(values):
            s.dp(0xa5,field); s.emit(0xc9,j)
            s.br(0xd0,f'next_{i}_{j}')
            write(s,value.ljust(max(map(len,values))))
            s.br(0x80,f'row_end_{i}')
            s.mark(f'next_{i}_{j}')
        s.mark(f'row_end_{i}')
    s.imm(15); s.sta(0x2100)
    s.mark('menu_wait')
    for expected, target in ((0xd0,'menu_end_blank'),(0xf0,'menu_start_blank')):
        s.mark(target); s.emit(0xad,0x12,0x42,0x29,0x80); s.br(expected,target)
    # Auto-joy starts shortly after vblank. Consume latest complete sample.
    s.mark('menu_poll'); s.emit(0xad,0x12,0x42,0x29,1); s.br(0xd0,'menu_poll')
    s.emit(0xad,0x19,0x42); s.dp(0x85,0x18)
    s.dp(0xa5,HELD); s.emit(0x49,255); s.dp(0x25,0x18); s.dp(0x85,0x19)
    s.dp(0xa5,0x18); s.dp(0x85,HELD)
    s.dp(0xa5,0x19); s.emit(0x29,0x10); s.br(0xd0,'menu_exit')
    for bit,delta in ((8,-1),(4,1)):
        label=f'menu_move_{bit}'
        s.dp(0xa5,0x19); s.emit(0x29,bit); s.br(0xf0,label)
        s.dp(0xa5,CURSOR); s.emit(0xc9,0 if delta<0 else len(ROWS)-1)
        s.br(0xf0,'menu_wait'); s.dp(0xc6 if delta<0 else 0xe6,CURSOR)
        s.br(0x80,'menu_refresh'); s.mark(label)
    s.dp(0xa5,0x19); s.emit(0x29,3); s.br(0xf0,'menu_wait')
    for i,(field,values) in enumerate(ROWS):
        s.dp(0xa5,CURSOR); s.emit(0xc9,i); s.br(0xd0,f'skip_field_{i}')
        s.dp(0xa5,0x19); s.emit(0x29,1); s.br(0xf0,f'field_left_{i}')
        s.dp(0xa5,field); s.emit(0xc9,len(values)-1); s.br(0xf0,'menu_wait')
        s.dp(0xe6,field); s.br(0x80,'menu_refresh'); s.mark(f'field_left_{i}')
        s.dp(0xa5,field); s.br(0xf0,'menu_wait'); s.dp(0xc6,field)
        s.br(0x80,'menu_refresh'); s.mark(f'skip_field_{i}')
    s.mark('menu_exit')
    s.imm(0x80); s.sta(0x2100)
    s.stz(0x2116); s.stz(0x2117); s.emit(0xa2,0,4)
    s.mark('erase_menu'); s.stz(0x2118); s.stz(0x2119); s.emit(0xca); s.br(0xd0,'erase_menu')
    s.dp(0xe6,CREDITS)  # convert selected index to actual remaining credits


def read_pad(s, joy, label):
    s.emit(0xad,joy&255,joy>>8)
    s.dp(0x85,0x1a)
    s.dp(0xa5,SWAP); s.br(0xf0,label+'_ready')
    # Swap Y/B only if exactly one is pressed.
    s.dp(0xa5,0x1a); s.emit(0x29,0xc0)
    s.br(0xf0,label+'_ready'); s.emit(0xc9,0xc0); s.br(0xf0,label+'_ready')
    s.dp(0xa5,0x1a); s.emit(0x49,0xc0); s.dp(0x85,0x1a)
    s.mark(label+'_ready'); s.dp(0xa5,0x1a)


def friendly_hits(s):
    for i,(x,y,hp,facing,other_x,other_y,other_hp,timer,joy) in enumerate((
        (0x20,0x21,0x35,0x34,0x22,0x23,0x3e,0x3f,0x4219),
        (0x22,0x23,0x3e,0x3d,0x20,0x21,0x35,0x36,0x421b))):
        done=f'friendly_done_{i}'
        latch=0x90+i
        read_pad(s,joy,f'friendly_pad_{i}')
        s.emit(0x29,0x40); s.br(0xd0,f'friendly_pressed_{i}')
        s.stz(latch); s.br(0x80,done)
        s.mark(f'friendly_pressed_{i}')
        s.dp(0xa5,latch); s.br(0xd0,done)
        s.imm(1); s.dp(0x85,latch)
        for field in (FRIENDLY,hp,other_hp):
            s.dp(0xa5,field); s.br(0xf0,done)
        s.dp(0xa5,timer); s.br(0xd0,done)
        s.dp(0xa5,y); s.emit(0x38); s.dp(0xe5,other_y)
        s.emit(0x1a,0xc9,3); s.br(0xb0,done)
        s.dp(0xa5,facing); s.br(0xf0,f'friendly_left_{i}')
        s.dp(0xa5,other_x); s.emit(0x38); s.dp(0xe5,x)
        s.br(0x80,f'friendly_range_{i}')
        s.mark(f'friendly_left_{i}'); s.dp(0xa5,x); s.emit(0x38); s.dp(0xe5,other_x)
        s.mark(f'friendly_range_{i}'); s.emit(0xc9,1); s.br(0x90,done)
        s.emit(0xc9,4); s.br(0xb0,done)
        s.dp(0xc6,other_hp); s.imm(45); s.dp(0x85,timer)
        s.dp(0xe6,0x83); s.dp(0xa5,0x83); s.sta(0x2141)
        s.mark(done)
