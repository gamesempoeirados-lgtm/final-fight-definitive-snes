"""Ground positions use 8px cells, pixel offsets, and a fractional speed carry."""
X_FINE=(0xb2,0xb4)
Y_FINE=(0xb3,0xb5)
X_CARRY=(0xb6,0xb8)
Y_CARRY=(0xb7,0xb9)
GAIT=(0xba,0xbb)
TOP=21
BOTTOM=25

def axis(s,i,cell,fine,carry,mask,positive,lo,hi,increment,whole):
    key=f'axis_{cell}'
    s.dp(0xa5,0x18);s.emit(0x29,mask);s.br(0xf0,key+'_done')
    s.emit(0xc9,mask);s.br(0xf0,key+'_done')
    s.dp(0x85,0xbd)
    if whole:
        s.emit(0x29,1);s.dp(0x85,(0x34,0x3d)[i])
    s.dp(0xa5,cell);s.dp(0x85,0x92);s.dp(0xa5,fine);s.dp(0x85,0x93)
    s.dp(0xa5,carry);s.emit(0x18,0x69,increment);s.dp(0x85,carry)
    s.imm(whole);s.emit(0x69,0);s.dp(0x85,0xbe);s.br(0xf0,key+'_done')
    s.dp(0xa5,cell);s.emit(10,10,10);s.dp(0x05,fine);s.dp(0x85,0xbf)
    # Compare the direction before loading the coordinate (LDA changes Z).
    s.dp(0xa5,0xbd);s.emit(0xc9,positive);s.br(0xd0,key+'_minus')
    s.dp(0xa5,0xbf);s.emit(0x18);s.dp(0x65,0xbe);s.emit(0xc9,hi*8);s.br(0x90,key+'_store');s.imm(hi*8);s.br(0x80,key+'_store')
    s.mark(key+'_minus');s.dp(0xa5,0xbf);s.emit(0x38);s.dp(0xe5,0xbe);s.emit(0xc9,lo*8);s.br(0xb0,key+'_store');s.imm(lo*8)
    s.mark(key+'_store');s.dp(0x85,0xbf);s.emit(0x29,7);s.dp(0x85,fine)
    s.dp(0xa5,0xbf);s.emit(0x4a,0x4a,0x4a);s.dp(0x85,cell)
    x=0x20+2*i
    s.dp(0xa5,x);s.dp(0x85,0xc0);s.dp(0xa5,x+1);s.dp(0x85,0xc1)
    s.jsr('barrel_test');s.br(0x90,key+'_done')
    s.dp(0xa5,0x92);s.dp(0x85,cell);s.dp(0xa5,0x93);s.dp(0x85,fine)
    s.mark(key+'_done')

def update(s,i,x,y):
    axis(s,i,x,X_FINE[i],X_CARRY[i],3,1,3,28,104,1)
    axis(s,i,y,Y_FINE[i],Y_CARRY[i],12,4,TOP,BOTTOM,171,0)
    s.dp(0xa5,0x18);s.emit(0x29,15);s.br(0xf0,f'gait_reset{i}')
    s.emit(0x29,3);s.br(0xf0,f'gait_vertical{i}');s.imm(38);s.br(0x80,f'gait_period{i}')
    s.mark(f'gait_vertical{i}');s.imm(40);s.mark(f'gait_period{i}');s.dp(0x85,0xbe)
    s.dp(0xe6,GAIT[i]);s.dp(0xa5,GAIT[i]);s.dp(0xc5,0xbe);s.br(0x90,f'gait_done{i}')
    s.mark(f'gait_reset{i}');s.stz(GAIT[i]);s.mark(f'gait_done{i}')

def barrier(s):
    # The barrel spans world X 101..138, with its base at screen Y 199.
    # Include the half-width of the feet and a shallow depth footprint.
    s.mark('barrel_test');s.dp(0xa5,0xc0);s.emit(0x18);s.dp(0x65,0x80)
    for lo,hi,axis in ((11,17,None),(22,24,0xc1)):
        if axis:s.dp(0xa5,axis)
        s.emit(0xc9,lo);s.br(0x90,'barrel_free');s.emit(0xc9,hi);s.br(0xb0,'barrel_free')
    s.emit(0x38,0x60);s.mark('barrel_free');s.emit(0x18,0x60)

def enemy_barrier(s,label):
    for src,dst in ((0x31,0xc0),(0x39,0xc1)):
        s.dp(0xa5,src);s.dp(0x85,dst)
    s.jsr('barrel_test');s.br(0x90,label)
    s.dp(0xa5,0x32);s.dp(0x85,0x31)
