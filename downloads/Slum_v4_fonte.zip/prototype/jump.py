"""Jump state for two players. One press launches a 24-frame arc."""
HEIGHT = [0xa0, 0xa1]
PHASE = [0xa2, 0xa3]
HELD = [0xa4, 0xa5]
ARC = tuple(round(24 * 4 * t * (24-t) / (24*24)) for t in range(25))


def update(s,i):
    phase, height, held = PHASE[i], HEIGHT[i], HELD[i]
    def label(text): return f'jump_{i}_{text}'
    s.dp(0xa5,0x18); s.emit(0x29,0x80)
    s.br(0xd0,label('press'))
    s.stz(held); s.br(0x80,label('tick'))
    s.mark(label('press')); s.dp(0xa5,held); s.br(0xd0,label('tick'))
    s.imm(1); s.dp(0x85,held)
    s.dp(0xa5,phase); s.br(0xd0,label('tick'))
    s.imm(1); s.dp(0x85,phase)
    s.mark(label('tick')); s.dp(0xa5,phase); s.br(0xf0,label('end'))
    s.emit(0xc2,0x20,0x29,0xff,0,0xaa,0xe2,0x20)
    s.emit(0xbd,0,0); s.fix.append(('abs',len(s.b)-2,'jump_arc'))
    s.dp(0x85,height); s.dp(0xe6,phase)
    s.dp(0xa5,phase); s.emit(0xc9,len(ARC)); s.br(0x90,label('end'))
    s.stz(phase); s.mark(label('end'))
