# Coop Street • protótipo SNES

Trecho de teste original com duas telas e três encontros. Abra `coop_street.sfc` em um emulador de Super Nintendo. No menu, use o direcional do controle 1 para escolher e Start para jogar. Cada controle move seu personagem, Y ataca e B inicia um salto de 24 quadros, com altura máxima de 24 pixels. Avance pela direita. Os dois jogadores vivos precisam acompanhar a câmera. Derrote cada inimigo para liberar o próximo trecho. O piso possui uma barreira. A vida e os inimigos ainda usam marcadores técnicos.

O menu permite 1 ou 2 jogadores, três dificuldades (2/3/4 pontos de vida por inimigo), 1–9 créditos de continuação, troca Y/B e dano entre jogadores. O padrão é 2 jogadores, Normal, 5 créditos, Y/B, dano entre jogadores desligado. Na derrota da equipe um crédito recupera os jogadores. Sem créditos, volta ao menu. Ao chegar ao fim da segunda tela, a câmera para.

## Como reproduzir

- `python3 build.py` gera a ROM de 32 KiB e report.json com checksum, SHA-256 e posições de código.
- `python3 test_runtime.py /caminho/snes9x2005_libretro.so` executa o teste usando o núcleo Snes9x2005 (libretro). Revisão testada a79dfe9047e7fec58808aefe48ad2bf499c7af11.
- `python3 tile_cache.py views.json 256` calcula os slots locais e os uploads de tiles para cada vista. A entrada é uma lista de vistas, cada qual com índices de tiles 8×8 na ordem de exibição. Os bytes informados cobrem só os gráficos dos tiles. O mapa e as paletas têm custos adicionais.
- O construtor deriva do build.py histórico da Etapa 82. O original recompilou byte a byte com SHA-256 512942b341b2c7ad30e6bb6cbadc3c4d0356e646440b44d377c1b52428fb3b96.

## Resultados medidos

- Teste cooperativo até o fim em 212 quadros de vídeo, 83 imagens distintas. Três encontros resolvidos com entradas normais. Segundo teste validou menu, modo solo, barreira, créditos e dano entre jogadores. A derrota usada para testar o crédito foi injetada em WRAM.
- Efeito original em BRR, 96 blocos, uma voz no SPC700, disparada por acerto. Pico de áudio medido de 9537 em PCM de 16 bits. O programa, o diretório e o som ocupam 1124 bytes contíguos a partir de $0200 da ARAM. Sem trilha musical nesta versão.
- BG1 reserva 2048 bytes de mapa e BG2, 4096. OBJ usa 2048 bytes de gráficos e duas entradas visíveis de 32×32. OAM recebe oito bytes de atributos por quadro após a inicialização. BG2 tem um mapa residente de 64×32 células. Nesta pista, seis tiles bastam para todas as 33 posições da câmera. A ferramenta de cache também reproduziu 800 vistas sintéticas. O jogo atual mantém o cenário inteiro residente.
- As escritas do mapa dinâmico ficam em fila e são aplicadas em VBlank. Cada célula custa dois bytes de mapa. O protótipo escreve por CPU. A margem temporal em um console físico continua pendente de medição.
- Na ROM SNES de referência game.sfc, 904 quadros em Snes9x2005 com instrumentação na entrada de S9xDoDMA mostraram 848 transferências para CGRAM, todas de $00:0BCF, de 512 bytes, começando na cor 0. Isso confirma o buffer de envio nesse intervalo. Falta identificar quem monta a paleta no buffer e associar cores a personagens e cenários.
- O decodificador 114–117 recuperado do histórico regenerou 4096 tiles 16×16 de Scroll2, equivalentes a 12477 tiles 8×8 únicos e 399264 bytes. Reconversão exata dos índices de pixels. Não foi identificado o mapa original de Slum.

Continuam pendentes a identificação e validação dos mapas e paletas do arcade, personagens e animações finais, música, introdução completa, ajuste do salto ao tempo do arcade e testes em hardware. Esta ROM usa apenas material gráfico e sonoro de teste.
