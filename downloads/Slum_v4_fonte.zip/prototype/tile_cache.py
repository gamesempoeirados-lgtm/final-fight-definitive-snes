"""Plan resident 4bpp tiles for a sequence of visible BG tile sets.

Input JSON is a list of lists of catalog indices in map order, one list per view.
Output transfers use byte lengths; remapped tile indices are local to the view.
"""
import json
import sys


def plan(views, capacity):
    if not 1 <= capacity <= 1024:
        raise ValueError('capacity must be between 1 and 1024 tile slots')
    resident = {}
    result = []
    for index, view in enumerate(views):
        if any(type(tile) is not int or tile < 0 for tile in view):
            raise ValueError(f'invalid catalog entry in view {index}')
        wanted = set(view)
        if len(wanted) > capacity:
            raise ValueError(f'view {index} needs {len(wanted)} slots')
        free = iter(sorted(set(range(capacity)) - {slot for tile,slot in resident.items() if tile in wanted}))
        loads = {}
        for tile in dict.fromkeys(view):
            if tile not in resident:
                loads[tile] = next(free)
        overwritten = set(loads.values())
        resident = {tile:slot for tile,slot in resident.items() if slot not in overwritten}
        resident.update(loads)
        result.append({'loads': list(loads.items()), 'tile_bytes': 32*len(loads),
                       'map_slots': [resident[tile] for tile in view]})
    return result


if __name__ == '__main__':
    with open(sys.argv[1]) as source:
        print(json.dumps(plan(json.load(source), int(sys.argv[2]))))
