"""Original two-screen test street. Positions and camera offsets use 8px cells."""

CAMERA = 0x80
WAVE = 0x81
QUEUE_BYTES = 0x82
QUEUE = 0x0300
CAMERA_END = 32


def street_tile(x, y):
    if 12 <= x < 15 and 20 <= y < 22:
        return 10
    if y < 5:
        return 0
    if y < 15:
        return 9 if x % 11 in (2, 3, 5, 6) and y % 5 in (1, 2) else 8
    if y == 15:
        return 10
    return 11 if (x + 2 * y) % 9 == 0 else 12


def initialize(s):
    # BG2 map at word $0400, 64x32; shared character base at word $1000.
    s.imm(5)
    s.sta(0x2108)
    s.imm(0x11)
    s.sta(0x210b)
    for register in (0x210f, 0x2110):
        s.stz(register)
        s.stz(register)
    s.imm(6)
    s.sta(0x2121)
    for color in (0x2108, 0x4ad6, 0x318c, 0x2529, 0x18c6):
        for byte in color.to_bytes(2, 'little'):
            s.imm(byte)
            s.sta(0x2122)
    s.stz(0x2116)
    s.imm(0x10)
    s.sta(0x2117)
    # Skip tiles 0..7 used by the existing renderer.
    s.imm(0x80)
    s.sta(0x2116)
    for tile in range(8, 13):
        for plane in (0, 2):
            for y in range(8):
                colors = [6 + tile - 8] * 8
                if tile == 8:
                    for x in range(8):
                        if y == 7 or (x + 4 * (y // 4)) % 8 == 0:
                            colors[x] = 10
                for bit, register in ((plane, 0x2118), (plane + 1, 0x2119)):
                    mask = sum(((color >> bit) & 1) << (7-x) for x, color in enumerate(colors))
                    s.imm(mask)
                    s.sta(register)
    s.stz(0x2116)
    s.imm(4)
    s.sta(0x2117)
    # SNES lays out a wide tilemap as two consecutive 32x32 pages.
    tiles = bytes(street_tile(32*page+x, y) for page in range(2)
                  for y in range(32) for x in range(32))
    words = bytearray(2 * len(tiles))
    words[::2] = tiles
    rom_stream(s, 'street_map', words, (0x2118, 0x2119))
    for field in (CAMERA, WAVE, QUEUE_BYTES, 0x79, 0x90, 0x91):
        s.stz(field)


def flush(s):
    s.emit(0xa2, 0, 0)  # LDX #0
    s.mark('flush_cell')
    s.emit(0x8a)  # TXA, 8-bit accumulator
    s.dp(0xc5, QUEUE_BYTES)
    s.br(0xf0, 'flush_done')
    for register in (0x2116, 0x2117, 0x2118):
        s.emit(0xbd, QUEUE & 255, QUEUE >> 8, 0xe8)
        s.sta(register)
    s.stz(0x2119)
    s.br(0x80, 'flush_cell')
    s.mark('flush_done')
    s.stz(QUEUE_BYTES)
    s.dp(0xa5, CAMERA)
    s.emit(0x0a, 0x0a, 0x0a)
    s.sta(0x210f)
    s.dp(0xa5, CAMERA)
    for _ in range(5):
        s.emit(0x4a)
    s.sta(0x210f)


def queue_cell(s):
    # draw() supplies word address in A16. Each queued cell occupies 3 bytes.
    s.dp(0x85, 0x14)
    s.emit(0xe2, 0x20)
    s.dp(0xa5, QUEUE_BYTES)
    # Zero extend X explicitly via 16-bit A.
    s.emit(0xc2, 0x20, 0x29, 0xff, 0, 0xaa, 0xe2, 0x20)
    for offset, field in enumerate((0x14, 0x15, 0x12)):
        s.dp(0xa5, field)
        s.emit(0x9d, (QUEUE+offset) & 255, QUEUE >> 8)
    s.emit(0x8a, 0x18, 0x69, 3)
    s.dp(0x85, QUEUE_BYTES)
    s.emit(0x60)


def advance(s):
    # Lock camera during a fight. A trailing living player can hold the camera.
    for hp in (0x30, 0x50, 0x60):
        s.dp(0xa5, hp)
        s.br(0xd0, 'camera_done')
    s.dp(0xa5, CAMERA)
    s.emit(0xc9, CAMERA_END)
    s.br(0xb0, 'camera_done')
    for i, (hp, x) in enumerate(((0x35, 0x20), (0x3e, 0x22))):
        s.dp(0xa5, hp)
        s.br(0xf0, f'trailer_ok_{i}')
        s.dp(0xa5, x)
        s.emit(0xc9, 3)
        s.br(0x90, 'camera_done')
        s.mark(f'trailer_ok_{i}')
    for hp, x in ((0x35, 0x20), (0x3e, 0x22)):
        s.dp(0xa5, hp)
        label = f'check_lead_{x}'
        s.br(0xf0, label)
        s.dp(0xa5, x)
        s.emit(0xc9, 22)
        s.br(0xb0, 'camera_step')
        s.mark(label)
    s.br(0x80, 'camera_done')
    s.mark('camera_step')
    s.dp(0xe6, CAMERA)
    for x in (0x20, 0x22):
        s.dp(0xa5, x)
        s.br(0xf0, f'no_shift_{x}')
        s.dp(0xc6, x)
        s.mark(f'no_shift_{x}')
    for index, (trigger, base, x, y) in enumerate(((6, 0x30, 26, 17), (20, 0x50, 24, 20), (30, 0x60, 26, 22))):
        s.dp(0xa5, CAMERA)
        s.emit(0xc9, trigger)
        s.br(0xd0, f'wave_skip_{index}')
        for off, val in ((0, 3), (1, x), (2, x), (9, y), (10, y)):
            if off == 0:
                s.dp(0xa5, 0x85)  # difficulty index 0..2
                s.emit(0x18, 0x69, 2)
            else:
                s.imm(val)
            s.dp(0x85, base + off)
        s.dp(0xe6, WAVE)
        s.mark(f'wave_skip_{index}')
    s.mark('camera_done')


def rom_stream(s, name, data, registers):
    """Copy ROM bytes through sequential PPU registers with 16-bit indexing."""
    s.emit(0xa2, 0, 0)
    s.mark(name + '_loop')
    for register in registers:
        s.emit(0xbd, 0, 0)
        s.fix.append(('abs', len(s.b)-2, name))
        s.sta(register)
        s.emit(0xe8)
    s.emit(0xe0, len(data) & 255, len(data) >> 8)
    s.br(0xd0, name + '_loop')
    s.br(0x80, name + '_end')
    s.mark(name)
    s.emit(*data)
    s.mark(name + '_end')


def block_barrier(s, index, x, y, previous_x, previous_y):
    """Use the same world-cell rectangle as the BG2 barrier pattern."""
    s.dp(0xa5, x)
    s.emit(0x18)
    s.dp(0x65, CAMERA)
    for low, high, axis in ((12,15,None),(20,22,y)):
        if axis is not None:
            s.dp(0xa5,axis)
        s.emit(0xc9,low)
        s.br(0x90,f'barrier_clear_{index}')
        s.emit(0xc9,high)
        s.br(0xb0,f'barrier_clear_{index}')
    for field, previous in ((x,previous_x),(y,previous_y)):
        s.dp(0xa5,previous)
        s.dp(0x85,field)
    s.mark(f'barrier_clear_{index}')
