#!/usr/bin/env python3
"""FastROM LoROM SNES two-player cooperative prototype with two-frame walking animation and cooperative combat; no enhancement chips."""
from pathlib import Path
import struct,json,hashlib
import punch
import jump
import slum_video
import street
import sound
import options
OUT=Path(__file__).resolve().parent
class Asm:
 def __init__(self):self.b=bytearray();self.labels={};self.fix=[]
 def mark(self,n):self.labels[n]=len(self.b)
 def emit(self,*x):self.b.extend(x)
 def imm(self,v):self.emit(0xa9,v)
 def sta(self,a):self.emit(0x8d,a&255,a>>8)
 def stz(self,a):self.emit(0x9c,a&255,a>>8)
 def dp(self,op,a):self.emit(op,a)
 def br(self,op,n):self.emit(op,0);self.fix.append(('rel',len(self.b)-1,n))
 def jsr(self,n):self.emit(0x20,0,0);self.fix.append(('abs',len(self.b)-2,n))
 def finish(self):
  # Expand out-of-range branches into an inverted short branch + absolute JMP.
  inverse={0xf0:0xd0,0xd0:0xf0,0x90:0xb0,0xb0:0x90,0x10:0x30,0x30:0x10,0x80:None}
  while True:
   expanded=False
   for i,(kind,pos,n) in enumerate(self.fix):
    if kind!='rel':continue
    delta=self.labels[n]-(pos+1)
    if -128<=delta<=127:continue
    op=self.b[pos-1]
    if op not in inverse:raise ValueError(('unknown branch',hex(op),n))
    if op==0x80:
     # BRA -> JMP abs (3 bytes vs 2)
     self.b[pos-1:pos+1]=bytes((0x4c,0,0))
     extra=1;newpos=pos
    else:
     # inverse branch skips JMP abs
     self.b[pos-1:pos+1]=bytes((inverse[op],3,0x4c,0,0))
     extra=3;newpos=pos+2
    cutoff=pos+1
    for label,offset in list(self.labels.items()):
     if offset>=cutoff:self.labels[label]=offset+extra
    updated=[]
    for j,(k,p,t) in enumerate(self.fix):
     if j==i:updated.append(('abs',newpos,n))
     else:updated.append((k,p+extra if p>=cutoff else p,t))
    self.fix=updated
    expanded=True
    break
   if not expanded:break
  for kind,pos,n in self.fix:
   t=self.labels[n]
   if kind=='rel':
    d=t-(pos+1)
    if not -128<=d<=127:raise ValueError((n,d))
    self.b[pos]=d&255
   else:struct.pack_into('<H',self.b,pos,0x8000+t)
  return self.b

s=Asm();e=s.emit
s.mark('reset');e(0x5c,0x10,0x80,0x80)
while len(s.b)<16:e(0xea)
s.mark('fast_entry')
e(0x78,0x18,0xfb) # SEI CLC XCE
# A=8, X/Y=16, stack=1fff
e(0xc2,0x10,0xe2,0x20,0xa2,0xff,0x1f,0x9a)
s.imm(0x80);s.sta(0x2100) # force blank
s.stz(0x4200);s.imm(1);s.sta(0x420d)
# palette 0 blue, palette 1 red, palette 2 green, palette 3 yellow, palette 4 white
s.stz(0x2121)
for color in (0x7c00,0x001f,0x03e0,0x03ff,0x7fff,0x7fe0):
 for v in (color&255,color>>8):s.imm(v);s.sta(0x2122)
s.imm(1);s.sta(0x2105) # mode 1
s.stz(0x2107) # BG1 tilemap word 0000
s.imm(1);s.sta(0x210b) # BG1 tiles at word 1000
s.stz(0x210d);s.stz(0x210d);s.stz(0x210e);s.stz(0x210e)
s.imm(0x80);s.sta(0x2115) # increment after high byte
s.stz(0x2116);s.stz(0x2117)
e(0xa2,0x00,0x04)
s.mark('clear_map');s.stz(0x2118);s.stz(0x2119);e(0xca);s.br(0xd0,'clear_map')
# BG tile 0 transparent, tile 1 solid color1, tile 2 solid color2
s.stz(0x2116);s.imm(0x10);s.sta(0x2117)
# SNES 4bpp tile layout: first 16 bytes are planes 0/1 (8 rows),
# next 16 bytes are planes 2/3 (8 rows). Never interleave plane pairs.
for tile in range(8):
 color_index = (0,1,2,3,4,5,1,5)[tile]
 for pair in (0,1):
  for row in range(8):
   pattern = (0x7e if row%2==0 else 0x3c) if tile>=6 else 0xff
   lo=pattern if (color_index & (1 << (pair*2))) else 0
   hi=pattern if (color_index & (1 << (pair*2+1))) else 0
   if lo:s.imm(lo);s.sta(0x2118)
   else:s.stz(0x2118)
   if hi:s.imm(hi);s.sta(0x2119)
   else:s.stz(0x2119)
# Initialize all OAM sprites offscreen. OAM low table has 128 four-byte entries.
s.stz(0x2102);s.stz(0x2103)
e(0xa2,0x80,0x00) # LDX #128 (16-bit X)
s.mark('oam_hide_loop')
for val in (0,240,0,0):
 s.imm(val);s.sta(0x2104)
e(0xca);s.br(0xd0,'oam_hide_loop')
# OAM high table: 32 bytes of zero (x high bit=0, sprite size small).
e(0xa2,0x20,0x00)
s.mark('oam_high_loop');s.stz(0x2104);e(0xca);s.br(0xd0,'oam_high_loop')
# OAM high-table first byte: sprite 0 and 1 use large (32x32) size.
s.imm(0x00);s.sta(0x2102);s.imm(0x01);s.sta(0x2103)
s.imm(0xaa);s.sta(0x2104);s.imm(0x0a);s.sta(0x2104)
# Two visible OBJ test markers, independently from BG1 gameplay.
s.stz(0x2102);s.stz(0x2103)
for x,y,tile in ((64,96,0),(184,96,4)):
 for val in (x,y,tile,0):s.imm(val);s.sta(0x2104)
sound.install(s)
s.mark('restart_stage')
for field in jump.HEIGHT+jump.PHASE+jump.HELD+list(punch.PHASE+punch.HELD): s.stz(field)
slum_video.load(s)
options.setup(s)
# initialize positions: P1(8,12), P2(23,12)
for addr,val in ((0x20,8),(0x21,18),(0x22,16),(0x23,18),(0x24,8),(0x25,18),(0x26,16),(0x27,18)):
 s.imm(val);s.dp(0x85,addr)
s.imm(0x13);s.sta(0x212c);s.imm(1);s.sta(0x4200) # BG1 + OBJ + autojoy
s.imm(0x0f);s.sta(0x2100)
# Enemy state: HP=3, x=16, previous x=16, last Y=0, P1 facing right=1
for addr,val in ((0x74,0),(0x30,0),(0x31,16),(0x32,16),(0x33,0),(0x34,1),(0x35,5),(0x36,0),(0x37,0),(0x38,0),(0x39,12),(0x3a,12),(0x3b,0)):
 s.imm(val);s.dp(0x85,addr)
# Enemy 2 and 3 records, matching the active enemy structure at $30-$3B.
# Fields: HP, X, previous X, Y-button latch, facing, unused, unused,
# AI tick, unused, Y, previous Y, stun.
for base,x,y in ((0x50,23,8),(0x60,25,19)):
 for off,val in ((0,0),(1,x),(2,x),(3,0),(4,1),(5,5),(6,0),(7,0),(8,0),(9,y),(10,y),(11,0),(12,0)):
  s.imm(val);s.dp(0x85,base+off)
s.imm(1);s.dp(0x85,0x3d) # P2 facing right
s.imm(5);s.dp(0x85,0x3e) # P2 HP
s.stz(0x3f) # P2 invulnerability
s.stz(0x3c) # P2 Y latch, active enemy
s.stz(0x79)
s.dp(0xa5,options.PLAYERS);s.br(0xd0,'players_ready');s.stz(0x3e)
s.mark('players_ready')
s.mark('frame')
s.dp(0xe6,0x79) # animation frame counter
s.mark('wait_end');e(0xad,0x12,0x42,0x29,0x80);s.br(0xd0,'wait_end')
s.mark('wait_start');e(0xad,0x12,0x42,0x29,0x80);s.br(0xf0,'wait_start')
street.flush(s)
slum_video.actors(s)
s.mark('wait_joy');e(0xad,0x12,0x42,0x29,1);s.br(0xd0,'wait_joy')
street.advance(s)
# read controller 1 low byte; UDLR in bits 3,2,1,0
for idx,(joy,buttons,x,y,oldx,oldy) in enumerate(((0x4219,0x4219,0x20,0x21,0x24,0x25),(0x421b,0x421b,0x22,0x23,0x26,0x27))):
 s.dp(0xa5,0x35 if idx==0 else 0x3e);s.br(0xf0,f'player_done_{idx}')
 options.read_pad(s,joy,f'move_pad_{idx}');s.dp(0x85,0x18)
 punch.update(s,idx)
 jump.update(s,idx)
 s.dp(0xa5,x);s.dp(0x85,0x92);s.dp(0xa5,y);s.dp(0x85,0x93)
 # directions each with boundaries
 for bit,axis,op,bound in ((0x02,x,'dec',1),(0x01,x,'inc',28),(0x08,y,'dec',17),(0x04,y,'inc',24)):
  n=f'p{idx}_{axis}_{op}'
  s.dp(0xa5,0x18);e(0x29,bit);s.br(0xf0,n+'_done')
  s.dp(0xa5,axis);e(0xc9,bound)
  s.br(0x90 if op=='dec' else 0xb0,n+'_done') # dec: skip if below 1; inc skip if >=30
  s.dp(0xc6 if op=='dec' else 0xe6,axis)
  if axis==x:
   s.imm(0 if op=='dec' else 1);s.dp(0x85,0x34 if idx==0 else 0x3d)
  s.mark(n+'_done')
 street.block_barrier(s,idx,x,y,0x92,0x93)
 s.dp(0xa5,x);s.dp(0x85,oldx);s.dp(0x85,0x10)
 s.dp(0xa5,y);s.dp(0x85,oldy);s.dp(0x85,0x11)
 s.mark(f'player_done_{idx}')
# Shared invulnerability timers: update once per frame, not once per enemy.
for addr in (0x36,0x3f):
 label=f'inv_done_{addr}'
 s.dp(0xa5,addr);s.br(0xf0,label)
 s.dp(0xc6,addr)
 s.mark(label)
options.friendly_hits(s)
# Process three enemy records independently using the same proven combat logic.
# Enemy 1 stays at $30-$3B. Others are copied to the active scratch record.
s.jsr('hit_check');s.jsr('p2_hit');s.jsr('enemy_ai')
for off in (0,1,2,3,7,9,10,11,12):
 s.dp(0xa5,0x30+off);s.dp(0x85,0x40+off)
for idx,base in enumerate((0x50,0x60)):
 for off in (0,1,2,3,7,9,10,11,12):
  s.dp(0xa5,base+off);s.dp(0x85,0x30+off)
 s.jsr('hit_check');s.jsr('p2_hit');s.jsr('enemy_ai')
 for off in (0,1,2,3,7,9,10,11,12):
  s.dp(0xa5,0x30+off);s.dp(0x85,base+off)
# Restore enemy 1 active record next frame from its dedicated snapshot.
# $40-$4B holds enemy 1 between frames.
for off in (0,1,2,3,7,9,10,11,12):
 s.dp(0xa5,0x40+off);s.dp(0x85,0x30+off)
# Five-segment player HP: green remaining, white depleted (row 1)
for i in range(5):
 s.imm(4+i);s.dp(0x85,0x10);s.imm(1);s.dp(0x85,0x11)
 s.imm(4);s.dp(0x85,0x12)
 s.dp(0xa5,0x35);e(0xc9,i+1);s.br(0x90,f'player_hp_{i}_empty')
 s.imm(2);s.dp(0x85,0x12)
 s.mark(f'player_hp_{i}_empty');s.jsr('draw')
# P2 health bar, right side of screen, cyan remaining / white depleted.
for i in range(5):
 s.imm(23+i);s.dp(0x85,0x10);s.imm(1);s.dp(0x85,0x11)
 s.imm(4);s.dp(0x85,0x12)
 s.dp(0xa5,0x3e);e(0xc9,i+1);s.br(0x90,f'p2_hp_{i}_empty')
 s.imm(5);s.dp(0x85,0x12)
 s.mark(f'p2_hp_{i}_empty');s.jsr('draw')
# Three-segment HP display: green for remaining HP, white for depleted.
# On defeat all three segments are white.
for i in range(3):
 s.imm(15+i);s.dp(0x85,0x10);s.imm(3);s.dp(0x85,0x11)
 s.imm(4);s.dp(0x85,0x12)
 s.dp(0xa5,0x30);e(0xc9,i+1);s.br(0x90,f'hp_{i}_empty')
 s.imm(2);s.dp(0x85,0x12)
 s.mark(f'hp_{i}_empty');s.jsr('draw')
# Continue automatically on party defeat while credits remain.
s.dp(0xa5,0x35);s.dp(0x05,0x3e);s.br(0xd0,'party_ready')
s.dp(0xa5,options.CREDITS);s.br(0xd0,'use_credit')
# Restart the setup screen without rebooting the running SPC.
s.imm(0x80);s.sta(0x2100);s.emit(0x4c,0,0);s.fix.append(('abs',len(s.b)-2,'restart_stage'))
s.mark('use_credit');s.dp(0xc6,options.CREDITS);s.imm(5);s.dp(0x85,0x35)
s.dp(0xa5,options.PLAYERS);s.br(0xf0,'solo_continue');s.imm(5);s.dp(0x85,0x3e)
s.mark('solo_continue');s.imm(60);s.dp(0x85,0x36);s.dp(0x85,0x3f)
s.mark('party_ready')
# jump to frame via JMP absolute (out of rel8 range)
e(0x4c,0,0);s.fix.append(('abs',len(s.b)-2,'frame'))
s.mark('enemy_ai')
s.dp(0xa5,0x30);s.br(0xf0,'ai_return')
# AI pursuit currently follows player 1; both players can hit enemies.

# stun timer pauses enemy movement and attacks after receiving a hit
s.dp(0xa5,0x3b);s.br(0xf0,'stun_done')
s.dp(0xc6,0x3b);e(0x60)
s.mark('stun_done')
# Choose the nearer living player by horizontal tile distance.
# Scratch $75/$76 hold target X/Y; $77 = player index (0 or 1).
s.dp(0xa5,0x20);s.dp(0x85,0x75)
s.dp(0xa5,0x21);s.dp(0x85,0x76)
s.stz(0x77)
s.dp(0xa5,0x35);s.br(0xd0,'target_p1_alive')
s.dp(0xa5,0x3e);s.br(0xf0,'ai_return')
s.br(0x80,'target_p2')
s.mark('target_p1_alive')
s.dp(0xa5,0x3e);s.br(0xf0,'target_chosen')
# absolute distance enemyX - P1X -> $78
s.dp(0xa5,0x31);e(0x38);s.dp(0xe5,0x20)
s.br(0x10,'dist1_positive');e(0x49,0xff,0x1a)
s.mark('dist1_positive');s.dp(0x85,0x78)
# absolute distance enemyX - P2X
s.dp(0xa5,0x31);e(0x38);s.dp(0xe5,0x22)
s.br(0x10,'dist2_positive');e(0x49,0xff,0x1a)
s.mark('dist2_positive');e(0xc5,0x78)
s.br(0xb0,'target_chosen')
s.mark('target_p2')
s.dp(0xa5,0x22);s.dp(0x85,0x75)
s.dp(0xa5,0x23);s.dp(0x85,0x76)
s.imm(1);s.dp(0x85,0x77)
s.mark('target_chosen')
# one AI step every 16 frames; keep previous x for erasure
s.dp(0xe6,0x37)
s.dp(0xa5,0x37);e(0x29,0x0f);s.br(0xd0,'ai_attack')
s.dp(0xa5,0x31);s.dp(0x85,0x32)
s.dp(0xa5,0x39);s.dp(0x85,0x3a)
# follow player's depth (Y axis), one tile per AI tick
s.dp(0xa5,0x39);e(0xc5,0x76);s.br(0xf0,'ai_y_done')
s.br(0x90,'ai_y_inc')
s.dp(0xc6,0x39);s.br(0x80,'ai_y_done')
s.mark('ai_y_inc');s.dp(0xe6,0x39)
s.mark('ai_y_done')
# approach player horizontally if farther than one tile
s.dp(0xa5,0x31);e(0x38);s.dp(0xe5,0x75)
s.br(0x90,'ai_move_left') # enemy is left of player
s.br(0xf0,'ai_attack')
e(0xc9,2);s.br(0x90,'ai_attack')
s.dp(0xc6,0x31);s.br(0x80,'ai_attack')
s.mark('ai_move_left')
s.dp(0xa5,0x75);e(0x38);s.dp(0xe5,0x31)
e(0xc9,2);s.br(0x90,'ai_attack')
s.dp(0xe6,0x31)
s.mark('ai_attack')
# attack every 32 frames if within 1 tile and same depth
s.dp(0xa5,0x37);e(0x29,0x1f);s.br(0xd0,'ai_return')
s.dp(0xa5,0x77);s.br(0xf0,'attack_check_p1_inv')
s.dp(0xa5,0x3f);s.br(0xd0,'ai_return')
s.br(0x80,'attack_inv_ok')
s.mark('attack_check_p1_inv')
s.dp(0xa5,0x36);s.br(0xd0,'ai_return')
s.mark('attack_inv_ok')
# enemy attacks only on same depth row or adjacent row
s.dp(0xa5,0x39);e(0x38);s.dp(0xe5,0x76)
s.br(0x10,'ai_depth_abs')
e(0x49,0xff,0x1a)
s.mark('ai_depth_abs');e(0xc9,2);s.br(0xb0,'ai_return')
s.dp(0xa5,0x31);e(0x38);s.dp(0xe5,0x75)
s.br(0x10,'ai_diff_positive') # BPL
# signed negative: two's complement
e(0x49,0xff,0x1a)
s.mark('ai_diff_positive')
e(0xc9,2);s.br(0xb0,'ai_return')
s.dp(0xa5,0x77);s.br(0xf0,'damage_p1')
s.dp(0xc6,0x3e);s.imm(45);s.dp(0x85,0x3f)
s.br(0x80,'ai_return')
s.mark('damage_p1')
s.dp(0xc6,0x35);s.imm(45);s.dp(0x85,0x36)
s.mark('ai_return');e(0x60)
s.mark('p2_hit')
# Temporarily swap P1 and P2 positions/facing/latch for reuse of collision logic.
# Save P1 state in $70..$73 and restore it after checking controller 2.
for a,b in ((0x20,0x70),(0x21,0x71),(0x34,0x72),(0x33,0x73)):
 s.dp(0xa5,a);s.dp(0x85,b)
for a,b in ((0x22,0x20),(0x23,0x21),(0x3d,0x34),(0x3c,0x33)):
 s.dp(0xa5,a);s.dp(0x85,b)
# Controller 2 input is selected via $74 for hit_check.
s.imm(1);s.dp(0x85,0x74)
s.jsr('hit_check')
s.stz(0x74)
s.dp(0xa5,0x33);s.dp(0x85,0x3c)
for a,b in ((0x70,0x20),(0x71,0x21),(0x72,0x34),(0x73,0x33)):
 s.dp(0xa5,a);s.dp(0x85,b)
e(0x60)
s.mark('hit_check')
s.dp(0xa5,0x74);s.br(0xf0,'jab_p1')
s.dp(0xa5,0x3e);s.br(0xf0,'hit_return');s.dp(0xa5,punch.PHASE[1]);s.br(0x80,'jab_contact')
s.mark('jab_p1');s.dp(0xa5,0x35);s.br(0xf0,'hit_return');s.dp(0xa5,punch.PHASE[0])
s.mark('jab_contact');e(0xc9,punch.EXTEND);s.br(0xd0,'hit_return')
s.dp(0xa5,0x30);s.br(0xf0,'hit_return')
# attack hits only within one depth tile
s.dp(0xa5,0x39);e(0x38);s.dp(0xe5,0x21)
s.br(0x10,'hit_depth_abs')
e(0x49,0xff,0x1a)
s.mark('hit_depth_abs');e(0xc9,2);s.br(0xb0,'hit_return')
# facing right: enemyX - playerX in [1,3]
s.dp(0xa5,0x34);s.br(0xf0,'hit_left')
s.dp(0xa5,0x31);e(0x38);s.dp(0xe5,0x20)
e(0xc9,1);s.br(0x90,'hit_return')
e(0xc9,4);s.br(0xb0,'hit_return')
s.br(0x80,'hit_success')
s.mark('hit_left')
s.dp(0xa5,0x20);e(0x38);s.dp(0xe5,0x31)
e(0xc9,1);s.br(0x90,'hit_return')
e(0xc9,4);s.br(0xb0,'hit_return')
s.mark('hit_success')
s.dp(0xe6,0x83);s.dp(0xa5,0x83);s.sta(0x2141)
s.dp(0xc6,0x30)
s.imm(12);s.dp(0x85,0x3b) # 12-frame stun on successful hit
# Store old enemy position and knock back one tile away from player
s.dp(0xa5,0x31);s.dp(0x85,0x32)
s.dp(0xa5,0x34);s.br(0xf0,'knock_left')
s.dp(0xa5,0x31);e(0xc9,29);s.br(0xb0,'hit_return')
s.dp(0xe6,0x31);s.br(0x80,'hit_return')
s.mark('knock_left')
s.dp(0xa5,0x31);e(0xc9,2);s.br(0x90,'hit_return')
s.dp(0xc6,0x31)
s.mark('hit_return');e(0x60)
s.mark('y_released');s.stz(0x33);e(0x60)
s.mark('draw')
# input $10 x, $11 y, $12 tile index; use 16-bit A for VRAM address
# temporary 16bit $14; DBR 0, DP 0
e(0xc2,0x20) # REP #20
s.dp(0xa5,0x11);e(0x29,0xff,0x00)
for _ in range(5):e(0x0a)
s.dp(0x85,0x14)
s.dp(0xa5,0x10);e(0x29,0xff,0x00);s.dp(0x05,0x14)
street.queue_cell(s)
s.mark('jump_arc');e(*jump.ARC)
code=s.finish();assert len(code)<0x7fc0,len(code)
rom=bytearray([0xff])*131072;rom[32768:32768+len(s.art)]=s.art;rom[:len(code)]=code
rom[0x7fc0:0x7fc0+21]=b'FINAL FIGHT SLUM TEST'
rom[0x7fd5]=0x30;rom[0x7fd6]=0;rom[0x7fd7]=7;rom[0x7fd8]=0;rom[0x7fd9]=1
rom[0x7fdc:0x7fe0]=b'\x00'*4
for p in (0x7ffa,0x7ffc,0x7ffe):struct.pack_into('<H',rom,p,0x8000)
checksum=(sum(rom)+510)&65535
struct.pack_into('<HH',rom,0x7fdc,checksum^0xffff,checksum)
p=OUT/'coop_street.sfc';p.write_bytes(rom)
report={'file':p.name,'bytes':len(rom),'code_bytes':len(code),'sha256':hashlib.sha256(rom).hexdigest(),'fastrom_header':hex(rom[0x7fd5]),'enhancement_chip':False,'reset_vector':hex(struct.unpack_from('<H',rom,0x7ffc)[0]),'checksum':hex(checksum),'tests':'build checks; run test_runtime.py for emulator checks','labels':s.labels}
assert rom[0x7fd5]==0x30 and rom[:4]==bytes((0x5c,0x10,0x80,0x80))
assert (sum(rom)-sum(rom[0x7fdc:0x7fe0])+510)&65535==checksum
(OUT/'report.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='labels'},indent=2))
