from pathlib import Path
import options,jump,punch

def load(s):
    assets=Path(__file__).with_name('slum')
    s.art=bytearray()
    for name,addr in [('bg.chr',0x4000),('bg.map',0x400),('obj0.chr',0x2000),('obj1.chr',0x3000),('bg.pal',16),('obj.pal',128)]:
        data=(assets/name).read_bytes()
        if len(s.art)%32768+len(data)>32768:s.art.extend(bytes(-len(s.art)%32768))
        bank,offset=divmod(len(s.art),32768);s.art.extend(data)
        cgram=name.endswith('.pal')
        if cgram:s.imm(addr);s.sta(0x2121)
        else:
            s.imm(addr&255);s.sta(0x2116);s.imm(addr>>8);s.sta(0x2117)
        for reg,value in [(0x4300,0 if cgram else 1),(0x4301,0x22 if cgram else 0x18),(0x4302,offset&255),(0x4303,0x80+(offset>>8)),(0x4304,0x81+bank),(0x4305,len(data)&255),(0x4306,len(data)>>8),(0x420b,1)]:
            s.imm(value);s.sta(reg)
    s.imm(0x41);s.sta(0x2101)
    s.imm(5);s.sta(0x2108);s.imm(0x41);s.sta(0x210b)
    for reg in (0x210f,0x2110):s.stz(reg);s.stz(reg)
    for reg in (0x80,0x81,0x82,0x79,0x90,0x91):s.stz(reg)

def actors(s):
    s.stz(0xb0);s.stz(0xb1)
    s.stz(0x2102);s.stz(0x2103)
    for i,(x,y,hp) in enumerate(((0x20,0x21,0x35),(0x22,0x23,0x3e),(0x31,0x39,0x30),(0x51,0x59,0x50),(0x61,0x69,0x60))):
        s.dp(0xa5,x);s.emit(10,10,10,0x38,0xe9,24);s.br(0xb0,f'x{i}');s.imm(0)
        s.mark(f'x{i}');s.sta(0x2104)
        s.dp(0xa5,hp);s.br(0xf0,f'hide{i}')
        s.dp(0xa5,y);s.emit(10,10,10,0x38,0xe9,47)
        if i<2:s.emit(0x38);s.dp(0xe5,jump.HEIGHT[i])
        s.br(0x80,f'height{i}');s.mark(f'hide{i}');s.imm(224)
        s.mark(f'height{i}');s.sta(0x2104)
        s.dp(0xa5,hp);s.br(0xd0,f'visible{i}')
        s.imm(128);s.sta(0x2104);s.imm(0x31);s.sta(0x2104);s.br(0x80,f'next{i}')
        s.mark(f'visible{i}')
        sizes=0xb0+i//4
        s.dp(0xa5,sizes);s.emit(0x09,2<<(2*(i%4)));s.dp(0x85,sizes)
        if i<2:
            s.dp(0xa5,punch.PHASE[i]);s.br(0xf0,f'moving{i}')
            s.emit(0xc9,5);s.br(0xb0,f'jab_arm{i}');s.imm(0);s.br(0x80,f'pose{i}')
            s.mark(f'jab_arm{i}');s.imm(136);s.br(0x80,f'pose{i}')
            s.mark(f'moving{i}');options.read_pad(s,0x4219+2*i,f'posepad{i}');s.emit(0x29,15);s.br(0xf0,f'pose{i}')
            s.dp(0xa5,0x79);s.emit(0x29,8);s.br(0xd0,f'pose{i}');s.imm(128)
            s.mark(f'pose{i}')
        else:
            s.dp(0xa5,(0x3b,0x5b,0x6b)[i-2]);s.br(0xf0,f'enemy_pose{i}')
            s.imm(128);s.mark(f'enemy_pose{i}')
        s.sta(0x2104)
        if i<2:
            s.dp(0xa5,0x34 if i==0 else 0x3d);s.br(0xd0,f'right{i}');s.imm(0x70);s.br(0x80,f'attr{i}')
            s.mark(f'right{i}');s.imm(0x30);s.mark(f'attr{i}')
            s.emit(0x48);s.dp(0xa5,punch.PHASE[i]);s.emit(0xc9,punch.EXTEND);s.br(0x90,f'jab_base{i}')
            s.emit(0xc9,punch.RETRACT);s.br(0xb0,f'jab_base{i}');s.emit(0x68,0x09,1);s.br(0x80,f'jab_attr{i}')
            s.mark(f'jab_base{i}');s.emit(0x68);s.mark(f'jab_attr{i}')
        else:
            s.imm(0x33)
        s.sta(0x2104);s.mark(f'next{i}')
    s.imm(11);s.emit(0x38);s.dp(0xe5,0x80);s.br(0x90,'barrel_hide')
    s.emit(10,10,10);s.sta(0x2104);s.imm(112);s.br(0x80,'barrel_y')
    s.mark('barrel_hide');s.stz(0x2104);s.imm(224);s.sta(0x2104);s.imm(128);s.sta(0x2104);s.imm(0x31);s.sta(0x2104);s.br(0x80,'barrel_done')
    s.mark('barrel_y');s.sta(0x2104);s.imm(8);s.sta(0x2104);s.imm(0x35);s.sta(0x2104)
    s.dp(0xa5,0xb1);s.emit(0x09,8);s.dp(0x85,0xb1);s.mark('barrel_done')
    # Hidden actors use the small OBJ size so the sprite cannot wrap to the top.
    s.stz(0x2102);s.imm(1);s.sta(0x2103)
    for sizes in (0xb0,0xb1):
        s.dp(0xa5,sizes);s.sta(0x2104)
